function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}// Definindo a classe Pessoa
class Pessoa {
  constructor(nome, local) {
    this.nome = nome;
    this.local = local;  // Inicializa a pessoa na cidade
  }

  // Método para ir ao campo
  irParaCampo() {
    console.log(`${this.nome} está saindo da cidade.`);
    setTimeout(() => {
      this.local = "campo";
      console.log(`${this.nome} chegou ao campo!`);
    }, 2000); // Simula o tempo de viagem
  }

  // Método para voltar para a cidade
  irParaCidade() {
    console.log(`${this.nome} está saindo do campo.`);
    setTimeout(() => {
      this.local = "cidade";
      console.log(`${this.nome} chegou à cidade.`);
    }, 2000); // Simula o tempo de viagem
  }
}

// Criando uma nova pessoa
let pessoa = new Pessoa("João", "cidade");

console.log(`${pessoa.nome} está na ${pessoa.local}.`);

// João vai para o campo
pessoa.irParaCampo();

// Após 3 segundos, João volta para a cidade
setTimeout(() => {
  pessoa.irParaCidade();
}, 3000);
